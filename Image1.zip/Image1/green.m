im = imread('testImage.png');
imshow(im);
im(:,:,1)=0;
im(:,:,3)=0;
figure;
imshow(im);
imwrite(im,'imgreen.png')