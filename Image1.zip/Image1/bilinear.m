clear all
close all
image='g.jpg';
%imagebig=imread('C:\Sandaruwan\Engineering\Image Processing & machine vision\Assignments\Images for A01\hgrgb.png');
factor=4;   %zooming factor
a=imread(image);      %import image"y.jpg"

[m, n, d] = size(a);  %3 dimentional array                 
rows=factor*m;
columns=factor*n;

for i=1:rows-1    
    x=i/factor;   
    x1=floor(x);
    x2=ceil(x);
    if x1==0
        x1=1;
    end
    xrem=rem(x,1);
    for j=1:columns        
        y=j/factor;
        
        y1=floor(y);
        y2=ceil(y);
        if y1==0
            y1=1;
        end
        yrem=rem(y,1);
        
        BottomLeft=a(x1,y1,:);
        TopLeft=a(x1,y2,:);
        BottomRight=a(x2,y1,:);
        TopRight=a(x2,y2,:);
        
        R1=BottomRight*yrem+BottomLeft*(1-yrem);
        R2=TopRight*yrem+TopLeft*(1-yrem);
        
        im_zoom(i,j,:)=R1*xrem+R2*(1-xrem);
    end
end
size(im_zoom)
%size(imagebig)
%ssd=sum(sum(sum((imagebig-im_zoom).*(imagebig-im_zoom))));
imwrite(im_zoom,'bilinear zoom.png');
imshow(im_zoom);