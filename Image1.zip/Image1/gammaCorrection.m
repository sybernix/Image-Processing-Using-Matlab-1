clc
clear
close all
image = imread('testImage.png');
image = im2double(image);
gamma = input('Enter gamma: ');
c=1/(1.0^gamma);
result = 255.0*c*((image/255.0).^gamma);
subplot(1,2,1)
imshow(image);
subplot(1,2,2)
imshow(result);
title('Processed')
imwrite(result, 'gammaCorrected.png')