imageBig = imread('g4.jpg');
nearestNeighbor = imread('bilinear zoom.png');
[a,b,c] = size(nearestNeighbor);
a=a-1

ssd1 = 0;
imageBig2 = im2double(imageBig);
nearestNeighbor2 = im2double(nearestNeighbor);
count = 0;
for k =1:3
    for i = 1:a
        for j = 1:b
            %count = count +1
            %i
            diff = (imageBig2(i,j,k) - nearestNeighbor2(i+1,j,k));
            %diff
            diff = diff*255;
            diff
            ssd1 = ssd1 + diff^2;
            %ssd1
        end
    end
end
%print ssd1;