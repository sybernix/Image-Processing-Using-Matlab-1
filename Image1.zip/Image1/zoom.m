function [ zoomedImage ] = zoom(imageInput, factor)

[m,n,d] = size(imageInput);
zoomedImage = zeros(m*factor, n*factor,d);
for i = 1:m*factor
    for j = 1:n*factor
        zoomedImage(i,j,:) = imageInput(ceil(i/factor),ceil(j/factor),:);
    end
end

end

