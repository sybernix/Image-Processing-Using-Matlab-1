clc
clear all
close all
img = imread('pout.tif');
%img = rgb2gray(im);
%imshow(im);
numBins = 256;
binBounds = linspace(0,255,numBins+1);
cumHist = zeros(numBins+1, 1);
for i = 2:numBins+1
    cumHist(i) = sum(sum(img<=binBounds(i)));
end
hist = cumHist(2:end) - cumHist(1:end-1);
binCenters = (binBounds(2:end) + binBounds(1:end-1))/2;


t = zeros(numBins,1);
[m,n] = size(img);
for i = 1:numBins
    tempsum=0;
    for j = 1:i
        tempsum = tempsum + hist(j);
    end
    t(i) = round(255.0*tempsum/(m*n));
end
s = t(img+1);
s=(mat2gray(s));

figure;
%subplot(1,2,1)
bar(binCenters,hist,0.2);
%subplot(1,2,2)
figure
imhist(im2double(s));
figure
%subplot(1,2,1)
imshow(img);
%subplot(1,2,2)
figure
imshow(s);
imwrite(s,'histogramEqualized.png')