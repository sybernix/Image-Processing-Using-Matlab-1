im = imread('testImage.png');
imshow(im);
imgray = rgb2gray(im);
figure;
imshow(imgray);
imwrite(imgray, 'imgray.png')