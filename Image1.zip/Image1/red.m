im = imread('testImage.png');
imshow(im);
im(:,:,3)=0;
im(:,:,2)=0;
figure;
imshow(im);
imwrite(im,'imred.png')