clc;
clear all;
close all;

g=0.5;
c=1/(1.0^g);
r=0:0.01:1
s = r
plot(s,r)