clear all
clc
close all
im = imread('testImage.png');
imshow(im);
im(:,:,1)=0;
im(:,:,2)=0;
figure;
imshow(im);
imwrite(im,'imblue.png')