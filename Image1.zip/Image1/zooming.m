clc;
clear all;
close all;

imageInput = imread('g.jpg');
%img = rgb2gray(img);
factor = input('Factor : ');
zoomedImage = zoom(imageInput, factor);

%zoomedImage= mat2gray(zoomedImage);
zoomedImage=uint8(zoomedImage);
imshow(zoomedImage);
imwrite(zoomedImage, 'zoomedImage.png');