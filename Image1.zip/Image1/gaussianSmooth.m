close all;
clc;

hw = 3;
a = hw;
b = hw;
[Y,X] = meshgrid(-a:a, -b:b);
sigma = 2;
g = exp(-(X.^2 + Y.^2)/sigma^2);
surf(g)
f = imread('noisy.jpg');
f = rgb2gray(f);
figure,
imshow(f);

[h, w] = size(f);
f = im2double(f);
o = zeros(h, w);

for m=a+1:h-a
    for n=b+1:w-b
        o(m,n) = sum(sum(f(m-a:m+a, n-b:n+b).*g));
    end
end

figure,
b = mat2gray(o);
imshow(b);
imwrite(b, 'gaussianSmooth.png');

sobelX = [-1, -2, -1; 0, 0, 0; 1, 2, 1];
sobelY = [-1, 0, 1; -2, 0, 2; -1, 0, 1];

outputImX = zeros(h, w);
outputImY = zeros(h, w);

for i = 2:h-1
    for j = 2:w-1
        outputImX(i,j) = (sum(sum(o(i-1:i+1, j-1:j+1).*sobelX)))/4;
    end
end
figure;
outputImX = mat2gray(outputImX);
imshow(outputImX);